import React, { Component } from 'react'
import Banner1 from '../../Assets/Images/image1.jpg'
import Banner2 from '../../Assets/Images/image2.jpg'
import {Carousel , Row , Col} from 'react-bootstrap'
import '../../Routes/Landing/style.scss'
import Page from '../../Components/HOC/Page'

class Landing extends Component{
    render(){
        return(
            <>
              <Page>
                <header>
                    <section>
                        <Carousel fade>
                                <Carousel.Item>
                                    <img
                                    className="d-block w-100"
                                    src={Banner2}
                                    alt="First slide"
                                    />
                                </Carousel.Item>
                                <Carousel.Item>
                                    <img
                                    className="d-block w-100"
                                    src={Banner1}
                                    alt="Second slide"
                                    />
                                </Carousel.Item>
                            </Carousel>
                    </section>
                        <section className="ToolBanner">
                            <div className="container-fluid">
                                <Row>
                                    <Col lg="12">
                                        <div className="ToolBannerText">
                                            <h1>Mukesh & Veera</h1>
                                        </div>
                                    </Col>
                                </Row>
                            </div>
                        
                        </section>
                    </header>
              </Page>
            </>
        )
    }
}
export default Landing