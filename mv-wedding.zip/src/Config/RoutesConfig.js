export const RoutesConfig = {
    LANDING: '/',
}