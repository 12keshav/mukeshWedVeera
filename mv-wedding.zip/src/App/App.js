import React from 'react'
import AppRoutes from '../Routes/index'
import '../App/style.scss'

function App() {
  return (
       <>
           <AppRoutes />
       </>
  );
}

export default App;
