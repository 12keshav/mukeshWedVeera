// export const Images = {
//     appleButton: require('../Assets/Images/apple-button.png'),
// }